<div class="container-fluid">
	<div class="sidenav">
         <div class="login-main-text" style="margin-top: 0px;">
         	
         	<div class="profileBx" align="center">
         		<img src="images/user.png" height="200"><br>
         		<strong><?php echo $_SESSION['username']; ?> </strong> - <?php echo strtoupper($_SESSION[login]); ?>
         		<br>
         		Email: <?php echo $_SESSION['email']; ?> <br>
         		Phone: <?php echo $_SESSION['phone']; ?>
            <br><br>
            <a href="signout.php" class="btn btn-lg btn-primary" style="color: white; text-decoration: none;">Logout</a>
         		

         	</div>
            
         </div>
      </div>




            <div class="main">

         <div class="col-md-12 col-lg-12 col-xl-12 col-sm-12">
         	<a href="index.php"><img src="images/logoNexus.png" height="70"></a>
           	<br><br><br><br><br>
           	<div class="row" align="center">
           	<div class="col-sm-4 col-md-4 col-lg-4"> 
            <div id="optionBox" align="center" style="margin-top: 20px;">
            	<a href="sublist.php" id="linkStyle"><span class="glyphicon glyphicon-search" style="font-size: 100px;"></span><br><br>View Test Subjects</a>
            </div>
            </div>
            <div class="col-sm-4 col-md-4 col-lg-4">
            <div id="optionBox" align="center" style="margin-top: 20px;">
            	<a href="result.php" id="linkStyle"><span class="glyphicon glyphicon-list-alt" style="font-size: 100px;"></span><br><br>Show Results</a>
            </div>
            </div>
           
           	<div class="col-sm-4 col-md-4 col-lg-4"> 
            <div id="optionBox" align="center" style="margin-top: 20px;">
            	<a href="signout.php" id="linkStyle"><span class="glyphicon glyphicon-log-out" style="font-size: 100px;"></span><br><br>Logout</a>
            </div>
            </div>
            </div>
             </div>
         </div>
      </div>


		</div>






















<!-- <h1 class='text-center bg-danger'>Welcome to Online Exam</h1>
		<table width="28%"  border="0" align="center">
  <tr>
    <td width="7%" height="65" valign="bottom"><img src="image/HLPBUTT2.JPG" width="50" height="50" align="middle"></td>
    <td width="93%" valign="bottom" bordercolor="#0000FF"> <a href="sublist.php" class="style4">Subject for Quiz </a></td>
  </tr>
  <tr>
    <td height="58" valign="bottom"><img src="image/DEGREE.JPG" width="43" height="43" align="absmiddle"></td>
    <td valign="bottom"> <a href="result.php" class="style4">Result </a></td>
  </tr>
</table> -->