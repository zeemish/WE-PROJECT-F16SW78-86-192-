<?php 
  session_start();
  if (isset($_SESSION['username'])) {
    header("location:index.php");
  }

 ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>New user signup </title>
<link rel="stylesheet" href="css/bootstrap.min.css"/>
<?php if (isset($_GET['signup'])): ?>
  <script type="text/javascript"> alert('Account already exisits');</script>
<?php endif ?>
<script language="javascript">
function check()
{

 if(document.form1.lid.value=="")
  {
    alert("Plese Enter Login Id");
	document.form1.lid.focus();
	return false;
  }
 
 if(document.form1.pass.value=="")
  {
    alert("Plese Enter Your Password");
	document.form1.pass.focus();
	return false;
  } 
  if(document.form1.cpass.value=="")
  {
    alert("Plese Enter Confirm Password");
	document.form1.cpass.focus();
	return false;
  }
  if(document.form1.pass.value!=document.form1.cpass.value)
  {
    alert("Confirm Password does not matched");
	document.form1.cpass.focus();
	return false;
  }
  if(document.form1.name.value=="")
  {
    alert("Plese Enter Your Name");
	document.form1.name.focus();
	return false;
  }
  if(document.form1.address.value=="")
  {
    alert("Plese Enter Address");
	document.form1.address.focus();
	return false;
  }
  if(document.form1.city.value=="")
  {
    alert("Plese Enter City Name");
	document.form1.city.focus();
	return false;
  }
  if(document.form1.phone.value=="")
  {
    alert("Plese Enter Contact No");
	document.form1.phone.focus();
	return false;
  }
  if(document.form1.email.value=="")
  {
    alert("Plese Enter your Email Address");
	document.form1.email.focus();
	return false;
  }
  e=document.form1.email.value;
		f1=e.indexOf('@');
		f2=e.indexOf('@',f1+1);
		e1=e.indexOf('.');
		e2=e.indexOf('.',e1+1);
		n=e.length;

		if(!(f1>0 && f2==-1 && e1>0 && e2==-1 && f1!=e1+1 && e1!=f1+1 && f1!=n-1 && e1!=n-1))
		{
			alert("Please Enter valid Email");
			document.form1.email.focus();
			return false;
		}
  return true;
  }
  
</script>
<link href="quiz.css" rel="stylesheet" type="text/css">
<style type="text/css">
  body {
    font-family: "Lato", sans-serif;
    background-color: white;
}



.main-head{
    height: 150px;
    background: #FFF;
   
}

.sidenav {
    height: 100%;
    background-color: purple;
    overflow-x: hidden;
    padding-top: 20px;
}


.main {
    padding: 0px 10px;
}

@media screen and (max-height: 450px) {
    .sidenav {padding-top: 15px;}
}

@media screen and (max-width: 450px) {
    .login-form{
        margin-top: 10%;
    }

    .register-form{
        margin-top: 10%;
    }
}

@media screen and (min-width: 768px){
    .main{
        margin-left: 30%; 
    }

    .sidenav{
        width: 30%;
        position: fixed;
        z-index: 1;
        top: 0;
        left: 0;
    }

    .login-form{
        margin-top: 0%;
    }

    .register-form{
        margin-top: 20%;
    }
}


.login-main-text{
    margin-top: 20%;
    padding: 60px;
    color: #fff;
}

.login-main-text h2{
    font-weight: 300;
}

.btn-black{
    background-color: #000 !important;
    color: #fff;
}
</style>
</head>

<body>
<?php
include("header.php");
?>

<div class="container">
      
      <div class="sidenav">
         <div class="login-main-text">
          
          <pre>{ Hello World }</pre><br>
          <h4>Welcome to <br> Nexus Online Testing Services<h4>
            
         </div>
      </div>
      <div class="main">

         <div class="col-md-6 col-sm-12">
          <a href="index.php"><img src="images/logoNexus.png" height="70"></a>
            <div class="login-form">
               <form name="form1" method="post" action="signupuser.php" onSubmit="return check();"> 
                <h2 align="center">Student Registration</h2>
                  <div class="form-group">
                     <label>Roll No.</label>
                     <input class="form-control"type="text" name="lid">
                  </div>
                  <div class="form-group">
                     <label>Password</label>
                     <input class="form-control"type="password" name="pass">
                  </div>
                  <div class="form-group">
                     <label>Confirm Password</label>
                     <input class="form-control" name="cpass" type="password" id="cpass">
                  </div>
                  <div class="form-group">
                     <label>Full Name</label>
                     <input class="form-control" name="name" type="text" id="name">
                  </div>
                  <div class="form-group">
                     <label>Address</label>
                     <textarea class="form-control" name="address" id="address"></textarea>
                  </div>
                  <div class="form-group">
                     <label>City</label>
                     <input class="form-control" name="city" type="text" id="city">
                  </div>
                  <div class="form-group">
                     <label>Phone Number</label>
                     <input class="form-control" name="phone" type="text" id="phone">
                  </div>
                  <div class="form-group">
                     <label>Email Address</label>
                     <input class="form-control" name="email" type="text" id="email">
                  </div>

                 <input class="btn btn-primary form-control" type="submit" name="Submit" value="Signup">
                 <br><br>
                  Already registered? <a href="index.php">Login</a>
               </form>
               
            </div>
         </div>
      </div>


    </div>




















<!--  <table width="50%" border="0">
   
   <tr>
     <td><form name="form1" method="post" action="signupuser.php" onSubmit="return check();">
       
			<table class=" table table-striped">
		
         <tr>
           <td class="style7">Roll no</td>
           <td><input class="form-control"type="text" name="lid"></td>
         </tr>
         <tr>
           <td class="style7">Password</td>
           <td><input class="form-control"type="password" name="pass"></td>
         </tr>
         <tr>
           <td class="style7" >Confirm Password </td>
           <td><input class="form-control" name="cpass" type="password" id="cpass"></td>
         </tr>
         <tr>
           <td class="style7">Name</td>
           <td><input class="form-control" name="name" type="text" id="name"></td>
         </tr>
         <tr>
           <td valign="top" class="style7">Address</td>
           <td><textarea class="form-control" name="address" id="address"></textarea></td>
         </tr>
         <tr>
           <td valign="top" class="style7">City</td>
           <td><input class="form-control" name="city" type="text" id="city"></td>
         </tr>
         <tr>
           <td valign="top" class="style7">Phone</td>
           <td><input class="form-control" name="phone" type="text" id="phone"></td>
         </tr>
         <tr>
           <td valign="top" class="style7">E-mail</td>
           <td><input class="form-control" name="email" type="text" id="email"></td>
         </tr>
         <tr>
           <td>&nbsp;</td>
           <td><input class="btn btn-danger" type="submit" name="Submit" value="Signup">
           </td>
         </tr>
       </table>
     </form></td>
   </tr>
 </table> -->
 <p>&nbsp; </p>
</body>
</html>
