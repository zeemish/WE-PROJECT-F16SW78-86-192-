<?php
session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Online Quiz - Test List</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="quiz.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/bootstrap.min.css"/>

<style type="text/css">
  body {
    font-family: "Lato", sans-serif;
}



.main-head{
    height: 150px;
    background: #FFF;
   
}

.sidenav {
    height: 100%;
    background-color: purple;
    overflow-x: hidden;
    padding-top: 20px;
}


.main {
    padding: 0px 10px;
}

@media screen and (max-height: 450px) {
    .sidenav {padding-top: 15px;}
}

@media screen and (max-width: 450px) {
    .login-form{
        margin-top: 10%;
    }

    .register-form{
        margin-top: 10%;
    }
}

@media screen and (min-width: 768px){
    .main{
        margin-left: 30%; 
    }

    .sidenav{
        width: 30%;
        position: fixed;
        z-index: 1;
        top: 0;
        left: 0;
    }

    .login-form{
        margin-top: 40%;
    }

    .register-form{
        margin-top: 20%;
    }
}


.login-main-text{
    margin-top: 20%;
    padding: 60px;
    color: #fff;
}

.login-main-text h2{
    font-weight: 300;
}

.btn-black{
    background-color: #000 !important;
    color: #fff;
}
#optionBox{
  width: 200px; 
  height: 200px; 
  box-shadow: 3px 3px 13px #888888; 
  background-color: #1111;
  padding: 20px;
  transition: 600ms;
}
#optionBox:hover{
  transition: 600ms;
  width: 200px; 
  height: 200px; 
  box-shadow: 3px 3px 13px #888888; 
  background-color: purple;
  text-decoration-color: white;
  padding: 20px;
}
#linkStyle{
  color: purple;
}
#linkStyle:hover{
  color: white;
}
#auth{
  transition: 1000ms;
}
.tableHead{
	background-color: purple;
	color: white;
}
</style>
</head>
<body>
<?php
// include("header.php");
include("database.php");


?>


		<div class="container-fluid">
	<div class="sidenav">
         <div class="login-main-text" style="margin-top: 0px;">
         	
         		<div class="profileBx" align="center">
         		<img src="images/user.png" height="200"><br>
         		<strong><?php echo $_SESSION['username']; ?> </strong> - <?php echo strtoupper($_SESSION['login']); ?>
         		<br>
         		Email: <?php echo $_SESSION['email']; ?> <br>
         		Phone: <?php echo $_SESSION['phone']; ?>
         		<br><br>
         		<a href="signout.php" class="btn btn-lg btn-primary" style="color: white; text-decoration: none;">Logout</a>

         	</div>
            
         </div>
      </div>




            <div class="main">

            	<div class="col-md-6 col-sm-12">
            <img src="images/logoNexus.png" height="70">
        </div>
        <div>
		<?php
		error_reporting(1);
		include("database.php");
		extract($_POST);
		extract($_GET);
		extract($_SESSION);
		// $rs=mysql_query($con,"select * from mst_question where test_id=$tid",$cn) or die(mysql_error());
		// if($_SESSION[qn]>mysql_num_rows($rs))
		// {
		// unset($_SESSION[qn]);
		// exit;
		// }
		if(isset($subid) && isset($testid))
		{
		$_SESSION[sid]=$subid;
		$_SESSION[tid]=$testid;
		header("location:quiz.php");
		}
		if(!isset($_SESSION[sid]) || !isset($_SESSION[tid]))
		{
			header("location: index.php");
		}
		?>

		<?php
		include("header.php");


		$query="select * from mst_question";

		$rs=mysqli_query($con,"select * from mst_question where test_id=$tid",$cn) or die(mysqli_error());
		if(!isset($_SESSION[qn]))
		{
			$_SESSION[qn]=0;
			mysqli_query("delete from mst_useranswer where sess_id='" . session_id() ."'") or die(mysqli_error());
			$_SESSION[trueans]=0;
			
		}
		else
		{	
				if($submit=='Next Question' && isset($ans))
				{
						mysqli_data_seek($rs,$_SESSION[qn]);
						$row= mysqli_fetch_row($rs);	
						mysqli_query($con,"insert into mst_useranswer(sess_id, test_id, que_des, ans1,ans2,ans3,ans4,true_ans,your_ans) values ('".session_id()."', $tid,'$row[2]','$row[3]','$row[4]','$row[5]', '$row[6]','$row[7]','$ans')") or die(mysqli_error());
						if($ans==$row[7])
						{
									$_SESSION[trueans]=$_SESSION[trueans]+1;
						}
						$_SESSION[qn]=$_SESSION[qn]+1;
				}
				else if($submit=='Get Result' && isset($ans))
				{
						mysqli_data_seek($rs,$_SESSION[qn]);
						$row= mysqli_fetch_row($rs);	
						mysqli_query($con,"insert into mst_useranswer(sess_id, test_id, que_des, ans1,ans2,ans3,ans4,true_ans,your_ans) values ('".session_id()."', $tid,'$row[2]','$row[3]','$row[4]','$row[5]', '$row[6]','$row[7]','$ans')") or die(mysqli_error());
						if($ans==$row[7])
						{
									$_SESSION[trueans]=$_SESSION[trueans]+1;
						}
						echo "<h1 class=head1> Result</h1>";
						$_SESSION[qn]=$_SESSION[qn]+1;
						echo "<Table align=center><tr class=tot><td>Total Question<td> $_SESSION[qn]";
						echo "<tr class=tans><td>True Answer<td>".$_SESSION[trueans];
						$w=$_SESSION[qn]-$_SESSION[trueans];
						echo "<tr class=fans><td>Wrong Answer<td> ". $w;
						echo "</table>";
						mysqli_query($con,"insert into mst_result(login,test_id,test_date,score) values('$login',$tid,'".date("d/m/Y")."',$_SESSION[trueans])") or die(mysqli_error());
						echo "<h1 align=center><a href=review.php> Review Question</a> </h1>";
						unset($_SESSION['qn']);
						unset($_SESSION['sid']);
						unset($_SESSION['tid']);
						unset($_SESSION['trueans']);
						exit;
				}
		}
		$rs=mysqli_query($con,"select * from mst_question where test_id=$tid",$cn) or die(mysqli_error());
		if($_SESSION['qn']>mysqli_num_rows($rs)-1)
		{
		unset($_SESSION['qn']);
		echo "<h1 class=head1>Some Error  Occured</h1>";
		session_destroy();
		echo "Please <a href=index.php> Start Again</a>";

		exit;
		}
		mysqli_data_seek($rs,$_SESSION['qn']);
		$row= mysqli_fetch_row($rs);
		echo "<form name=myfm method=post action=quiz.php  style='margin-top: 100px;'>";
		echo "<table width=100%> <tr> <td width=30>&nbsp;<td> <table border=0>";
		$n=$_SESSION['qn']+1;
		echo "<tR><td><span class=style2>Que ".  $n .": $row[2]</style>";
		echo "<tr><td class=style8><input type=radio name=ans value=1>$row[3]";
		echo "<tr><td class=style8> <input type=radio name=ans value=2>$row[4]";
		echo "<tr><td class=style8><input type=radio name=ans value=3>$row[5]";
		echo "<tr><td class=style8><input type=radio name=ans value=4>$row[6]";

		if($_SESSION['qn']<mysqli_num_rows($rs)-1)
		echo "<tr><td><input type=submit name=submit value='Next Question'></form>";
		else
		echo "<tr><td><input type=submit name=submit value='Get Result'></form>";
		echo "</table></table>";
		?>

		</div>


        </div>

</div>




</body>
</html>