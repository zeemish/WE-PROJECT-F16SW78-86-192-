<?php
session_start();
if (!isset($_SESSION['username'])) {
	header("location:index.php");
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Online Quiz - Test List</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="quiz.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/bootstrap.min.css"/>

<style type="text/css">
  body {
    font-family: "Lato", sans-serif;
}



.main-head{
    height: 150px;
    background: #FFF;
   
}

.sidenav {
    height: 100%;
    background-color: purple;
    overflow-x: hidden;
    padding-top: 20px;
}


.main {
    padding: 0px 10px;
}

@media screen and (max-height: 450px) {
    .sidenav {padding-top: 15px;}
}

@media screen and (max-width: 450px) {
    .login-form{
        margin-top: 10%;
    }

    .register-form{
        margin-top: 10%;
    }
}

@media screen and (min-width: 768px){
    .main{
        margin-left: 30%; 
    }

    .sidenav{
        width: 30%;
        position: fixed;
        z-index: 1;
        top: 0;
        left: 0;
    }

    .login-form{
        margin-top: 40%;
    }

    .register-form{
        margin-top: 20%;
    }
}


.login-main-text{
    margin-top: 20%;
    padding: 60px;
    color: #fff;
}

.login-main-text h2{
    font-weight: 300;
}

.btn-black{
    background-color: #000 !important;
    color: #fff;
}
#optionBox{
  width: 200px; 
  height: 200px; 
  box-shadow: 3px 3px 13px #888888; 
  background-color: #1111;
  padding: 20px;
  transition: 600ms;
}
#optionBox:hover{
  transition: 600ms;
  width: 200px; 
  height: 200px; 
  box-shadow: 3px 3px 13px #888888; 
  background-color: purple;
  text-decoration-color: white;
  padding: 20px;
}
#linkStyle{
  color: purple;
}
#linkStyle:hover{
  color: white;
}
#auth{
  transition: 1000ms;
}
.tableHead{
	background-color: purple;
	color: white;
}
</style>
</head>
<body>
<?php
include("header.php");
include("database.php");


?>


		<div class="container-fluid">
	<div class="sidenav">
         <div class="login-main-text" style="margin-top: 0px;">
         	
         	<div class="profileBx" align="center">
         		<img src="images/user.png" height="200"><br>
         		<strong><?php echo $_SESSION['username']; ?> </strong> - <?php echo strtoupper($_SESSION['login']); ?>
         		<br>
         		Email: <?php echo $_SESSION['email']; ?> <br>
         		Phone: <?php echo $_SESSION['phone']; ?>
         		<br><br>
         		<a href="signout.php" class="btn btn-lg btn-primary" style="color: white; text-decoration: none;">Logout</a>

         	</div>
            
         </div>
      </div>




            <div class="main">

         <div class="col-sm-12">
         	<a href="index.php"><img src="images/logoNexus.png" height="70"></a>
           	<div class="row">
           	<div class="col-sm-09"> 

           		<h3 align="center">This page is under construction</h3>
           		<a href="index.php" class="btn btn-primary" style="color: white; text-decoration: none;"><span class="fa fa-angle-left">Go Back</span></a>

           	</div>
           </div>
       </div>
   </div>
            

           		<!-- Show Test -->


<?php
// extract($_SESSION);
// $rs=mysqli_query($con,"select t.test_name,t.total_que,r.test_date,r.score from mst_test t, mst_results r where
// t.test_id=r.test_id and r.login='$login'",$cn) or die(mysqli_error());

// echo "<h1 class=head1> Result </h1>";
// if(mysqli_num_rows($rs)<1)
// {
// 	echo "<br><br><h1 class=head1> You have not given any quiz</h1>";
// 	exit;
// }
// echo "<table border=1 align=center><tr class=style2><td width=300>Test Name <td> Total<br> Question <td> Score";
// while($row=mysqli_fetch_row($rs))
// {
// echo "<tr class=style8><td>$row[0] <td align=center> $row[1] <td align=center> $row[3]";
// }
// echo "</table>";
?>
</body>
</html>
