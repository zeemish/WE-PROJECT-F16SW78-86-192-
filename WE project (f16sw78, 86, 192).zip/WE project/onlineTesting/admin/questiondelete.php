<?php
session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Online Quiz - Quiz List</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link href="../quiz.css" rel="stylesheet" type="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<!-- <link href="quiz.css" rel="stylesheet" type="text/css">
 --><link rel="stylesheet" href="css/bootstrap.min.css"/>
<SCRIPT LANGUAGE="JavaScript">
function check() {
mt=document.form1.addque.value;
if (mt.length<1) {
alert("Please Enter Question");
document.form1.addque.focus();
return false;
}
a1=document.form1.ans1.value;
if(a1.length<1) {
alert("Please Enter Answer1");
document.form1.ans1.focus();
return false;
}
a2=document.form1.ans2.value;
if(a1.length<1) {
alert("Please Enter Answer2");
document.form1.ans2.focus();
return false;
}
a3=document.form1.ans3.value;
if(a3.length<1) {
alert("Please Enter Answer3");
document.form1.ans3.focus();
return false;
}
a4=document.form1.ans4.value;
if(a4.length<1) {
alert("Please Enter Answer4");
document.form1.ans4.focus();
return false;
}
at=document.form1.anstrue.value;
if(at.length<1) {
alert("Please Enter True Answer");
document.form1.anstrue.focus();
return false;
}
return true;
}
</script>
<style type="text/css">
	#response{
		transition: 1000ms;
	}
</style>
</head>
<body>



<?php
include("header.php");
include("../database.php");
require("../database.php");
?>
<?php
extract($_POST);

echo "<BR>";
if (!isset($_SESSION[alogin]))
{
	echo "<br><h2><div  class=head1>You are not Logged On Please Login to Access this Page</div></h2>";
	echo "<a href=index.php><h3 align=center>Click Here for Login</h3></a>";
	exit();
}
if($_POST[submit]=='Save' || strlen($_POST['testid'])>0 )
{
extract($_POST);
mysqli_query($con,"insert into mst_question(test_id,que_desc,ans1,ans2,ans3,ans4,true_ans) values ('$testid','$addque','$ans1','$ans2','$ans3','$ans4','$anstrue')",$cn) or die(mysqli_error());
echo "<p align=center id='response' class='well alert-danger'>Question Added Successfully.</p>";
unset($_POST);
}
?>
<div class="container-fluid">


	<form class="form-inline" name="form1" align="center" method="post" onSubmit="return check();">
		<select class="form-control" name="testid" id="testid"> 
			<option disabled selected>--Select Test Topic--</option>
			<?php
			$rs=mysqli_query($con,"Select * from mst_test order by test_name",$cn);
			    while($row=mysqli_fetch_array($rs))
			{
			if($row[0]==$testid)
			{
			echo "<option value='$row[0]' selected>$row[2]</option>";
			}
			else
			{
			echo "<option value='$row[0]'>$row[2]</option>";
			}
			}
			?>
      	</select> <br><br>
      <textarea class="form-control" placeholder="Type your question here..." name="addque" cols="60" rows="2" id="addque"></textarea> <textarea class="form-control" placeholder="Correct Answer" name="anstrue" cols="60" rows="2" id="anstrue"></textarea><br><br>
      	<div class="form-group">
      		<label for="ans1"> A:</label>
      		<input class="form-control" name="ans1" type="text" id="ans1" placeholder="Option A" size="35">
      	</div>
      	<div class="form-group">
      		<label for="ans2"> B:</label>
      		<input class="form-control" placeholder="Option B" name="ans2" type="text" id="ans2" size="35">
      	</div><br><br>
	    <div class="form-group">
	      	<label for="ans3"> C:</label>
	      	<input class="form-control" placeholder="Option C" name="ans3" type="text" id="ans3" size="35">
	  	</div>
	  	<div class="form-group">
      		<label for="ans4"> D:</label>
      		<input class="form-control" placeholder="Option D" name="ans4" type="text" id="ans4" size="35">
      	</div><br><br>
      
      <input class="btn btn-primary" type="submit" name="submit" value="Add">
  </form>
<hr>

<?php
$sql=mysqli_query($con,"select * from mst_question");	
	
	echo "<table class='table table-striped'>";
	echo "<tr>
	<th class='text-primary'>ID</th>
	<th class='text-primary'>Question</th>
	<th class='text-primary'>Option A</th>
	<th class='text-primary'>Option B</th>
	<th class='text-primary'>Option C</th>
	<th class='text-primary'>Option D</th>
	<th class='text-primary'>Correct Answer</th>
	<th class='text-primary'>Update</th>
	<th class='text-primary'>Delete</th></tr>";
	
	while($result=mysqli_fetch_assoc($sql))
	{
$id=$result['que_id'];
	
	echo "<tr>";	
	echo "<td>".$result['que_id']. "</td>";
	echo "<td>".$result['que_desc']."</td>";
	echo "<td>".$result['ans1']."</td>";
	echo "<td>".$result['ans2']."</td>";
	echo "<td>".$result['ans3']."</td>";
	echo "<td>".$result['ans4']."</td>";
	echo "<td>".$result['true_ans']."</td>";
	echo "<td><a href='queupdate.php?que_id=$id'><span class='glyphicon glyphicon-edit'></span></a></td>";
	echo "<td><a href='quedelete.php?que_id=$id'><span class='glyphicon glyphicon-trash'></span></a></td>";
	echo "</tr>";
	}
	echo "</table>";
?>


</div>
</body>
</html>



<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>