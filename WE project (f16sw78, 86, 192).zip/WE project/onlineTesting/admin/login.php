<?php
session_start();
error_reporting(1);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Adminstrative AreaOnline Quiz </title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../quiz.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/bootstrap.min.css"/>
<style type="text/css">
	body {
    font-family: "Lato", sans-serif;
}



.main-head{
    height: 150px;
    background: #FFF;
   
}

.sidenav {
    height: 100%;
    background-color: purple;
    overflow-x: hidden;
    padding-top: 20px;
}


.main {
    padding: 0px 10px;
}

@media screen and (max-height: 450px) {
    .sidenav {padding-top: 15px;}
}

@media screen and (max-width: 450px) {
    .login-form{
        margin-top: 10%;
    }

    .register-form{
        margin-top: 10%;
    }
}

@media screen and (min-width: 768px){
    .main{
        margin-left: 30%; 
    }

    .sidenav{
        width: 30%;
        position: fixed;
        z-index: 1;
        top: 0;
        left: 0;
    }

    .login-form{
        margin-top: 40%;
    }

    .register-form{
        margin-top: 20%;
    }
}


.login-main-text{
    margin-top: 20%;
    padding: 60px;
    color: #fff;
}

.login-main-text h2{
    font-weight: 300;
}

.btn-black{
    background-color: #000 !important;
    color: #fff;
}
#optionBox{
	width: 200px; 
	height: 200px; 
	box-shadow: 3px 3px 13px #888888; 
	background-color: #1111;
	padding: 20px;
	transition: 600ms;
}
#optionBox:hover{
	transition: 600ms;
	width: 200px; 
	height: 200px; 
	box-shadow: 3px 3px 13px #888888; 
	background-color: purple;
	text-decoration-color: white;
	padding: 20px;
}
#linkStyle{
	color: purple;
}
#linkStyle:hover{
	color: white;
}
#auth{
	transition: 1000ms;
}
</style>

</head>

<body>
<?php

include("../database.php");

?>



<div class="container">
      
      <div class="sidenav">
         <div class="login-main-text">
          
          <pre>{ Hello Administrator }</pre><br>
          <h4>Welcome to <br> Nexus Online Testing Services</h4>
            
         </div>
      </div>
    	<div class="main">
        	<div class="col-sm-12">
          		<img src="../images/logoNexus.png" height="70">
     		</div>
     		<br><br><br><br><br><br><br>
           	
           	<div class="row" align="center">
           		<div class="col-sm-4">
           			<div id="optionBox" align="center">
           				<a href="viewsub.php" id="linkStyle"><span class="glyphicon glyphicon-book" style="font-size: 100px;"></span><br><br>View Subjects</a>
           			</div>
           		</div>
           		<div class="col-sm-4">
           			<div id="optionBox" align="center">
           				<a href="testview.php" id="linkStyle"><span class="glyphicon glyphicon-align-justify" style="font-size: 100px;"></span><br><br>View Tests</a>
           			</div>
           		</div>
           		<div class="col-sm-4">
           			<div id="optionBox" align="center">
           				<a href="questiondelete.php" id="linkStyle"><span class="glyphicon glyphicon-th-list" style="font-size: 100px;"></span><br><br>View Question</a>
           			</div>
           		</div>
           	</div>
           	<br><br><br><br>
           	<div class="row" align="center">
           		<div class="col-sm-4">
           			<div id="optionBox" align="center">
           				<a href="showuser.php" id="linkStyle"><span class="glyphicon glyphicon-user" style="font-size: 100px;"></span><br><br>View User</a>
           			</div>
           		</div>
           		<div class="col-sm-4">
           			<div id="optionBox" align="center">
           				<a href="signout.php" id="linkStyle"><span class="glyphicon glyphicon-log-out" style="font-size: 100px;"></span><br><br>Logout</a>
           			</div>
           		</div>
           	</div>


    	</div>






<?php
extract($_POST);
if(isset($submit))
{
	$rs=mysqli_query($con,"select * from mst_admin where loginid='$loginid' and pass='$pass'",$cn) or die(mysqli_error());
	if(mysqli_num_rows($rs)<1)
	{
		echo "<BR><BR><BR><BR><div class=head1> Invalid User Name or Password<br>
		<a href='index.php'>Click here to login again </a>
		<div>";
	//exit;
		echo "<script>window.location='index.php'</script>";		
	}
	else
	{
	echo "<script>window.location='login.php'</script>";			
	$_SESSION['alogin']="true";
	}
}
else if(!isset($_SESSION[alogin]))
{
	echo "<BR><BR><BR><BR><div class=head1> Your are not logged in<br> Please <a href=index.php>Login</a><div>";
		exit;
}
?>

</div>


</body>
</html>
