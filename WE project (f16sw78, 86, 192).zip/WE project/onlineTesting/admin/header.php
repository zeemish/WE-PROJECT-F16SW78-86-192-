
<link rel="stylesheet" href="css/bootstrap.min.css"/>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>

<style type="text/css">
body {
    font-family: "Lato", sans-serif;
}

.nav{
	display: inline-block;
}
.main-head{
    height: 150px;
    background: #FFF;
   
}

.sidenav {
    height: 100%;
    background-color: purple;
    overflow-x: hidden;
    padding-top: 20px;
}


.main {
    padding: 0px 10px;
}

@media screen and (max-height: 450px) {
    .sidenav {padding-top: 15px;}
}

@media screen and (max-width: 450px) {
    .login-form{
        margin-top: 10%;
    }

    .register-form{
        margin-top: 10%;
    }
}

@media screen and (min-width: 768px){
    .main{
        margin-left: 0%; 
    }

    .sidenav{
        width: 30%;
        position: fixed;
        z-index: 1;
        top: 0;
        left: 0;
    }

    .login-form{
        margin-top: 40%;
    }

    .register-form{
        margin-top: 20%;
    }
}


.login-main-text{
    margin-top: 20%;
    padding: 60px;
    color: #fff;
}

.login-main-text h2{
    font-weight: 300;
}

.btn-black{
    background-color: #000 !important;
    color: #fff;
}
#optionBox{
	width: 200px; 
	height: 200px; 
	box-shadow: 3px 3px 13px #888888; 
	background-color: #1111;
	padding: 20px;
	transition: 600ms;
}
#optionBox:hover{
	transition: 600ms;
	width: 200px; 
	height: 200px; 
	box-shadow: 3px 3px 13px #888888; 
	background-color: purple;
	text-decoration-color: white;
	padding: 20px;
}
#linkStyle{
	color: purple;
}
#linkStyle:hover{
	color: white;
}
#auth{
	transition: 1000ms;
}
#link1:hover{
	background-color: purple;
	color: white;
}
</style>

  <Table width="100%">
  <tr>
  <td>
  <?php @$_SESSION['login']; 
  error_reporting(1);
  ?>
  </td>
    <td>
	
<?php
	if(isset($_SESSION['alogin']))
	{
	
		?>

	 <div class="container-fluid">
			<nav class="navbar navbar-default">
			  <div class="container-fluid">
			    <!-- Brand and toggle get grouped for better mobile display -->
			    <div class="navbar-header">
			      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
			        <span class="sr-only">Toggle navigation</span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			      </button>
			      <a class="navbar-brand" href="login.php"><img src="../images/logoNexus.png" height="40"></a>
			    </div>

			    <!-- Collect the nav links, forms, and other content for toggling -->
			    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			      <ul class="nav navbar-nav"> 
			        <li ><a href="login.php" id="link1">Home</a></li>
			        <li><a href="viewsub.php" id="link1">View Subject</a></li>
			        <li><a href="testview.php" id="link1">View Tests</a></li>
			        <li><a href="questiondelete.php" id="link1">View Questions</a></li>
			        <li><a href="showuser.php" id="link1">View Users</a></li>
			        
			      </ul>
			      
			      <ul class="nav navbar-nav navbar-right">
			        <li class="dropdown">
			          <a href="signout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a>
			        </li>
			      </ul>
			    </div><!-- /.navbar-collapse -->
			  </div><!-- /.container-fluid -->
			</nav>	 	
     
     		
           	
	 
<?php
	 }
	 else
	 {
	 	echo "&nbsp;";
	 }
	?>
		</td>
	
  </tr>
  
</table>
</div> 	