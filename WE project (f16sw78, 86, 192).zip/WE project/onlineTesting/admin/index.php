<?php
session_start();
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Administrative Login - Online Exam</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../quiz.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/bootstrap.min.css"/>
<style type="text/css">
  body {
    font-family: "Lato", sans-serif;
}



.main-head{
    height: 150px;
    background: #FFF;
   
}

.sidenav {
    height: 100%;
    background-color: purple;
    overflow-x: hidden;
    padding-top: 20px;
}


.main {
    padding: 0px 10px;
}

@media screen and (max-height: 450px) {
    .sidenav {padding-top: 15px;}
}

@media screen and (max-width: 450px) {
    .login-form{
        margin-top: 10%;
    }

    .register-form{
        margin-top: 10%;
    }
}

@media screen and (min-width: 768px){
    .main{
        margin-left: 30%; 
    }

    .sidenav{
        width: 30%;
        position: fixed;
        z-index: 1;
        top: 0;
        left: 0;
    }

    .login-form{
        margin-top: 40%;
    }

    .register-form{
        margin-top: 20%;
    }
}


.login-main-text{
    margin-top: 20%;
    padding: 60px;
    color: #fff;
}

.login-main-text h2{
    font-weight: 300;
}

.btn-black{
    background-color: #000 !important;
    color: #fff;
}
#optionBox{
  width: 200px; 
  height: 200px; 
  box-shadow: 3px 3px 13px #888888; 
  background-color: #1111;
  padding: 20px;
  transition: 600ms;
}
#optionBox:hover{
  transition: 600ms;
  width: 200px; 
  height: 200px; 
  box-shadow: 3px 3px 13px #888888; 
  background-color: purple;
  text-decoration-color: white;
  padding: 20px;
}
#linkStyle{
  color: purple;
}
#linkStyle:hover{
  color: white;
}
#auth{
  transition: 1000ms;
}
</style>
</head>

<body>
<?php
//include("header.php");
?>


<div class="container">
      
      <div class="sidenav">
         <div class="login-main-text">
          
          <pre>{ Hello World }</pre><br>
          <h4>Welcome to <br> Nexus Online Testing Services<h4>
            
            
         </div>
      </div>
      <div class="main">

         <div class="col-md-6 col-sm-12">
          <img src="../images/logoNexus.png" height="70">
            <div class="login-form">
               <form method="post" action="login.php"> 
                <h2 align="center">Teachers Login</h2>
                  <div class="form-group">
                     <label>Login Id</label>
                     <input class="form-control" name="loginid" required="true" type="text" id="loginid">

                  </div>
                  <div class="form-group">
                     <label>Password</label>
                     <input class="form-control" name="pass" type="password" required="true" id="pass">
                  </div>
                  <input class="btn btn-primary form-control" type="submit" name="submit" id="submit" Value="Login"/><br><br>
                  <a href="../" class="btn btn-success form-control" style="color: white;">Login as a Student</a><br><br>
                  
          <?php
            if(isset($found))
            {
              echo "<br><div class='alert alert-danger' id='auth'>Wrong Authentication</div>";
            }
            ?>
               </form>
               
            </div>
         </div>
      </div>


    </div>




























<!-- <h1 class="text-center bg-danger">Adminstrative Login</h1>
<form name="form1" method="post" action="login.php">
<table class="table table-striped">
  <tr>
    <td width="106"><span class="style2"></span></td>
    <td width="132"><span class="style2"><span class="head1"><img src="login.jpg" width="131" height="155"></span></span></td>
    <td width="238"><table width="219" border="0" align="center">
  <tr>
    <td width="163" class="style2">Login ID </td>
    <td width="149"><input class="form-control" name="loginid" type="text" id="loginid"></td>
  </tr>
  <tr>
    <td class="style2">Password</td>
    <td><input class="form-control" name="pass" type="password" id="pass"></td>
  </tr>
  <tr>
    <td class="style2">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td class="style2">&nbsp;</td>
    <td><input class="btn btn-primary" name="submit" type="submit" id="submit" value="Login"></td>
  </tr>
</table></td>
  </tr>
</table>

</form> -->

</body>
</html>
