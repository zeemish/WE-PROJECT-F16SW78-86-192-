<?php
session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Online Quiz - Quiz List</title>
<link href="../quiz.css" rel="stylesheet" type="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="quiz.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/bootstrap.min.css"/>
<SCRIPT LANGUAGE="JavaScript">
function check() {
mt=document.form1.testname.value;
if (mt.length<1) {
alert("Please Enter Test Name");
document.form1.testname.focus();
return false;
}
tt=document.form1.totque.value;
if(tt.length<1) {
alert("Please Enter Total Question");
document.form1.totque.value;
return false;
}
return true;
}
</script>
</head>
<body>
<?php
include("header.php");
include("../database.php");
if($_POST[submit]=='Save' || strlen($_POST['subid'])>0 )
{
extract($_POST);
mysqli_query($con,"insert into mst_test(sub_id,test_name,total_que) values ('$subid','$testname','$totque')",$cn) or die(mysqli_error());
echo "<p align=center>Test <b>\"$testname\"</b> Added Successfully.</p>";
unset($_POST);
}
?>


			<div class="container-fluid">
		<form class="form-inline" align="center" name="form1" method="post" onSubmit="return check();">
			<select class="form-control" name="subid">
				<option selected disabled>--Select Subject--</option>
				<?php
				$rs=mysqli_query($con,"Select * from mst_subject order by  sub_name",$cn);
					  while($row=mysqli_fetch_array($rs))
				{
				if($row[0]==$subid)
				{
				echo "<option value='$row[0]' selected>$row[1]</option>";
				}
				else
				{
				echo "<option value='$row[0]'>$row[1]</option>";
				}
				}
				?>
      		</select>
      		<input class="form-control" name="testname" placeholder="Name of Topic" type="text" id="testname">
      		<input class="form-control" placeholder="Total no. of Questions" name="totque" type="text" id="totque">
      		<input class="form-control btn btn-primary" type="submit" name="submit" value="Add New Test" >
		</form>
	<hr>




<?php
$sql=mysqli_query($con,"select * from mst_test");	
	
	echo "<table class='table table-striped'>";
	echo "<tr><th class='text-primary'>ID</th><th class='text-primary'>name</th>
	<th class='text-primary'>Total question</th>
	<th class='text-primary'>Subject</th>
	<th class='text-primary'>Update</th>
	<th class='text-primary'>Delete</th></tR>";
	
	while($result=mysqli_fetch_assoc($sql))
	{
		$subId = $result['sub_id'];
		$q = "select * from mst_subject where sub_id = '".$subId."'";
		$sql2 = mysqli_query($con, $q) or die(mysqli_error($con));
			while ($res=mysqli_fetch_assoc($sql2)) 
			{
				$id=$result['test_id'];				
				echo "<tr>";	
				echo "<td>".$result['test_id']. "</td>";
				echo "<td>".$result['test_name']."</td>";
				echo "<td>".$result['total_que']."</td>";
				echo "<td>".$res['sub_name']."</td>";
				echo "<td><a href='testupdate.php?test_id=$id'><span class='glyphicon glyphicon-edit'></span></a></td>";
				echo "<td><a href='testdelete.php?test_id=$id'><span class='glyphicon glyphicon-trash'></span></a></td>";
				echo "</tr>";
		}
	}
	echo "</table>";


?>
</div>

</body>
</html>
