<?php
session_start();
if (!isset($_SESSION['username'])) {
  header("location:index.php");
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Online Quiz - Quiz List</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="quiz.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/bootstrap.min.css"/>
<style type="text/css">
  body {
    font-family: "Lato", sans-serif;
}



.main-head{
    height: 150px;
    background: #FFF;
   
}

.sidenav {
    height: 100%;
    background-color: purple;
    overflow-x: hidden;
    padding-top: 20px;
}


.main {
    padding: 0px 10px;
}

@media screen and (max-height: 450px) {
    .sidenav {padding-top: 15px;}
}

@media screen and (max-width: 450px) {
    .login-form{
        margin-top: 10%;
    }

    .register-form{
        margin-top: 10%;
    }
}

@media screen and (min-width: 768px){
    .main{
        margin-left: 30%; 
    }

    .sidenav{
        width: 30%;
        position: fixed;
        z-index: 1;
        top: 0;
        left: 0;
    }

    .login-form{
        margin-top: 40%;
    }

    .register-form{
        margin-top: 20%;
    }
}


.login-main-text{
    margin-top: 20%;
    padding: 60px;
    color: #fff;
}

.login-main-text h2{
    font-weight: 300;
}

.btn-black{
    background-color: #000 !important;
    color: #fff;
}
#optionBox{
  width: 200px; 
  height: 200px; 
  box-shadow: 3px 3px 13px #888888; 
  background-color: #1111;
  padding: 20px;
  transition: 600ms;
}
#optionBox:hover{
  transition: 600ms;
  width: 200px; 
  height: 200px; 
  box-shadow: 3px 3px 13px #888888; 
  background-color: purple;
  text-decoration-color: white;
  padding: 20px;
}
#linkStyle{
  color: purple;
}
#linkStyle:hover{
  color: white;
}
#auth{
  transition: 1000ms;
}
.tableHead{
	background-color: purple;
	color: white;
}
</style>
</head>
<body>
	<div class="container-fluid">
	<div class="sidenav">
         <div class="login-main-text" style="margin-top: 0px;">
         	
         	<div class="profileBx" align="center">
         		<img src="images/user.png" height="200"><br>
         		<strong><?php echo $_SESSION['username']; ?> </strong> - <?php echo strtoupper($_SESSION['login']); ?>
         		<br>
         		Email: <?php echo $_SESSION['email']; ?> <br>
         		Phone: <?php echo $_SESSION['phone']; ?>
         		<br><br>
         		<a href="signout.php" class="btn btn-lg btn-primary" style="color: white; text-decoration: none;">Logout</a>

         	</div>
            
         </div>
      </div>




            <div class="main">

         <div class="col-sm-12">
         	<a href="index.php"><img src="images/logoNexus.png" height="70"></a>
           	<div class="row">
           	<div class="col-sm-09"> 
            

           		<!-- Subject Table -->

           		<?php
					
					include("database.php");
					echo "<h1 class='well bg-danger'>Select Subject to Give Quiz</h1>";
					$rs=mysqli_query($con,"select * from mst_subject");

					echo "<div style='padding: 0px;'>";
					echo "<table class='table table-striped table-hover table-bordered table-primary'>";
					echo "
						<thead class='tableHead'>
							<tr>
								<th>Subject Id</th>
								<th>Subject Name</th>
							</tr>
						</thead>
						";
					while($row=mysqli_fetch_row($rs))
					{

						if (!isset($row[0])) {
							echo "<tbody><tr><td align=center >No Suject found</td></tbody>";
						}
						else{
						echo "<tbody><tr><td>$row[0]</td><td><a href=showtest.php?subid=$row[0]><font size=4>$row[1]</font></a></tbody>";
						}
					}
					echo "</table>";
					?>
		</div>






            </div>
            </div>
         </div>
      </div>


		</div>


</body>
</html>
